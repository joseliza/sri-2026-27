# Laboratorio DNS con BIND9

Laboratorio con tres contenedores Docker para practicar con un servidor DNS
primario y otro secundario (BIND9) y un cliente desde el que hacer consultas.

## Esquema

Red interna: `172.20.0.0/24`

| Contenedor | IP            | Función                          | Acceso desde el host |
|------------|---------------|----------------------------------|----------------------|
| `ns1`      | `172.20.0.2`  | Servidor primario (autoritativo) | `127.0.0.2:53`       |
| `ns2`      | `172.20.0.3`  | Servidor secundario              | `127.0.0.3:53`       |
| `cliente`  | `172.20.0.10` | Herramientas: `dig`, `nslookup`, `ping`, `tcpdump`... | — |

El dominio del laboratorio es **`sri.com`** y su zona inversa es
**`0.20.172.in-addr.arpa`**.

Equipos definidos en la zona:

| Nombre          | Tipo  | Valor          |
|-----------------|-------|----------------|
| `ns1.sri.com`   | A     | `172.20.0.2`   |
| `ns2.sri.com`   | A     | `172.20.0.3`   |
| `www.sri.com`   | A     | `172.20.0.20`  |
| `mail.sri.com`  | A     | `172.20.0.30`  |
| `web.sri.com`   | CNAME | `www.sri.com`  |
| `sri.com`       | MX    | `10 mail.sri.com` |

## Requisitos

- Docker y Docker Compose v2 (se usa `docker compose`, con espacio).
- Los puertos `53/udp` y `53/tcp` libres en `127.0.0.2` y `127.0.0.3`.
- **Linux:** funciona directamente.
- **macOS:** primero hay que crear las IP en loopback:
  `sudo ifconfig lo0 alias 127.0.0.2` y `sudo ifconfig lo0 alias 127.0.0.3`.
- **Windows (Docker Desktop):** debería funcionar; si no, haced las pruebas
  desde el contenedor `cliente`, que no necesita nada del host.

## Puesta en marcha

```bash
docker compose up -d --build     # construye las imágenes y arranca el laboratorio
docker compose ps                # comprobar que los tres contenedores están "running"
docker exec -it cliente bash     # entrar en el cliente para hacer las pruebas
```

Para parar el laboratorio:

```bash
docker compose down              # elimina los contenedores (se pierden los cambios)
```

## Estructura del proyecto

```
.
├── docker-compose.yml
├── docker-compose.webmin.yml  # extra opcional: Webmin en ns1
├── primario/
│   ├── Dockerfile
│   ├── entrypoint.sh          # arranca Webmin (si está) y named
│   ├── named.conf.options     # opciones globales (comentadas)
│   ├── named.conf.local       # declaración de las zonas (type master)
│   ├── db.sri.com             # zona directa
│   └── db.172.20.0            # zona inversa
├── secundario/
│   ├── Dockerfile
│   ├── named.conf.options
│   └── named.conf.local       # zonas como type slave, masters 172.20.0.2
└── cliente/
    ├── Dockerfile
    └── entrypoint.sh          # configura /etc/resolv.conf con ns1 y ns2
```

La configuración de BIND está **dentro de los contenedores**, en las rutas por
defecto de Debian (`/etc/bind`). Las zonas del secundario se descargan solas del
primario y se guardan en `/var/cache/bind`.

El cliente usa `ns1` y `ns2` como servidores DNS, con `search sri.com`, así que
`www` se resuelve como `www.sri.com`.

## Pruebas básicas (desde el contenedor `cliente`)

```bash
# Resolución directa
dig www.sri.com
dig @172.20.0.2 www.sri.com          # preguntando al primario
dig @172.20.0.3 www.sri.com          # preguntando al secundario

# Otros tipos de registro
dig sri.com NS
dig sri.com MX
dig web.sri.com CNAME
dig sri.com SOA

# Resolución inversa
dig -x 172.20.0.20

# Transferencia de zona
dig @172.20.0.2 sri.com AXFR         # desde el cliente: debe ser rechazada
```

Desde el host (Linux) también se puede consultar:

```bash
dig @127.0.0.2 www.sri.com
dig @127.0.0.3 www.sri.com
```

## Modificar la configuración

Se edita dentro del contenedor con `nano` o `vi`:

```bash
docker exec -it ns1 nano /etc/bind/db.sri.com
```

Después de cambiar una zona:

1. **Incrementar el serial** del SOA (si no, el secundario no se entera).
2. Comprobar la sintaxis:
   ```bash
   docker exec ns1 named-checkconf
   docker exec ns1 named-checkzone sri.com /etc/bind/db.sri.com
   ```
3. Recargar:
   ```bash
   docker exec ns1 rndc reload
   ```
4. Comprobar que el secundario ha recibido el cambio:
   ```bash
   dig @172.20.0.3 sri.com SOA +short
   ```

> **Importante:** los cambios se conservan con `docker compose restart`, pero se
> **pierden con `docker compose down`**, que devuelve el laboratorio al estado
> inicial. Si queréis guardar vuestro trabajo, copiad los ficheros al host:
> `docker cp ns1:/etc/bind/db.sri.com .`

Para ver los registros de BIND:

```bash
docker logs ns1
docker logs -f ns2       # en directo
```

Para reconstruir desde cero tras cambiar algo en las carpetas del proyecto:

```bash
docker compose down
docker compose up -d --build
```

## Extra opcional: Webmin en ns1

Interfaz web para administrar BIND en `ns1`. **No se instala por defecto**; se
activa añadiendo el fichero `docker-compose.webmin.yml`:

```bash
docker compose -f docker-compose.yml -f docker-compose.webmin.yml up -d --build
```

- URL: <http://127.0.0.2:10000> · usuario `root` · contraseña `webmin`
  (para cambiarla: `WEBMIN_PASSWORD=miclave docker compose -f ... up -d --build`).
- Módulo a usar: *Servers → BIND DNS Server*.
- Para volver al laboratorio sin Webmin: `docker compose down` y
  `docker compose up -d --build`.

> Webmin puede reescribir los ficheros de zona y de configuración y perder su
> formato y los comentarios. Recomendación: primero haced las prácticas a mano y
> usad Webmin después para comparar el resultado.

## Ejercicios propuestos

1. Comprobad con `dig` que `ns1` y `ns2` devuelven la misma respuesta para
   `www.sri.com`. ¿Qué diferencia hay en el flag `aa` y en el resto de la cabecera?
2. Añadid un registro `A` `ftp` con la IP `172.20.0.40` y su `PTR` en la zona
   inversa. Incrementad los seriales, recargad y comprobad que el secundario lo
   resuelve.
3. Parad el primario (`docker stop ns1`) y comprobad que el cliente sigue
   resolviendo gracias al secundario. Volved a arrancarlo con `docker start ns1`.
4. Intentad una transferencia de zona desde el cliente
   (`dig @172.20.0.2 sri.com AXFR`) y desde el secundario. ¿Qué opción de
   `named.conf.options` explica la diferencia?
5. Preguntad por un dominio externo (`dig @172.20.0.2 google.com`). ¿Qué
   respuesta obtenéis y por qué? Revisad la opción `recursion`.
6. Con `tcpdump` en el cliente (`tcpdump -n -i eth0 port 53`), observad el
   tráfico de una consulta y el de una transferencia de zona entre ns1 y ns2.
7. Modificad el serial del primario sin recargar y comprobad cuánto tarda el
   secundario en actualizarse. Después recargad y comparad (opciones `notify` y
   `also-notify`).

## Problemas frecuentes

| Síntoma | Causa probable |
|---------|----------------|
| `address already in use` al arrancar | Otro servicio usa el puerto 53 en `127.0.0.2` o `127.0.0.3`. |
| `cannot assign requested address` (macOS) | Faltan los alias de loopback (ver Requisitos). |
| El secundario no se actualiza | No se incrementó el serial del SOA, o se olvidó recargar el primario. |
| `connection timed out; no servers could be reached` | Los contenedores no están levantados: `docker compose ps`. |
| Mis cambios han desaparecido | Se ejecutó `docker compose down`; ver el aviso de arriba. |
