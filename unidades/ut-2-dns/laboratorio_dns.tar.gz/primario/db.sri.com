$TTL 1h
@   IN  SOA ns1.sri.com. admin.sri.com. (
            2024010101  ; serial (incrementar en cada cambio)
            1h          ; refresh
            15m         ; retry
            1w          ; expire
            1h )        ; negative cache TTL

; Servidores de nombres
@       IN  NS      ns1.sri.com.
@       IN  NS      ns2.sri.com.

; Servidor de correo
@       IN  MX  10  mail.sri.com.

; Equipos (registros A)
ns1     IN  A       172.20.0.2
ns2     IN  A       172.20.0.3
www     IN  A       172.20.0.20
mail    IN  A       172.20.0.30

; Alias (CNAME)
web     IN  CNAME   www.sri.com.
