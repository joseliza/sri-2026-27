#!/bin/sh
# Si Webmin está instalado (imagen construida con WEBMIN=1), lo arranca en
# segundo plano (puerto 10000) con la contraseña de WEBMIN_PASSWORD.
if [ -x /etc/webmin/start ]; then
    /usr/share/webmin/changepass.pl /etc/webmin root "${WEBMIN_PASSWORD:-webmin}" >/dev/null
    /etc/webmin/start
fi
exec "$@"
