#!/bin/sh
# Docker fuerza su DNS embebido (127.0.0.11); aquí usamos directamente
# nuestros servidores ns1 y ns2 para que los alumnos vean el comportamiento real.
cat > /etc/resolv.conf <<EOT
search sri.com
nameserver 172.20.0.2
nameserver 172.20.0.3
EOT
exec "$@"
